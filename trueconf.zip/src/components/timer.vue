<template>
    <div class="timer">{{newTime}}
    </div>
</template>

<script>
export default {
  name: 'timer',
  props: ['currentTime'],
  data: function () {
    return {
      newTime: this.currentTime
    }
  },
  mounted () {
    setInterval(() => {
      if (this.newTime > 1) {
        this.newTime--
      }
      else if (this.newTime == 1) {
        this.newTime = this.currentTime
      }
    }, 1001)
  }
}


</script>

<style>
  .timer {
    width: 50px;
    height: 50px;
    background: green;
    border: 2px solid #000;
    border-radius: 5px;
    margin: 10px auto;
    overflow: hidden;
    line-height: 50px;
    font-size: 25px;
    text-align: center;
    color: yellow;
  }
</style>
